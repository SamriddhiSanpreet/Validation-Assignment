   
// This import syntax is used to import the useState hook in this file...

   import { useState } from "react";
   
// This is the main Validation Form Section...

   export default function Validation(){

        // Storing the data through useState Hook....

        const[name,setName]=useState('');
        const[email,setEmail]=useState('');
        const[pass,setPass]=useState('');
        const[errMsg,setErrorMsg]=useState({});

        // Creation of an error message by creating an arrow function...

        const handleForm = (e) =>{
            e.preventDefault();

            let errobj={};

            // Conditions to passing an error messages...

            if(!name){
                errobj.name ="Name is required !!"
            }
            else if(!email){
                errobj.email ="Email is required !!"
            }
            else if(!pass){
                errobj.pass="Password is required !!"
            }

            // Conditions for consoling the data...

            if(Object.keys(errobj).length>0){
                setErrorMsg(errobj)
            }
            else{
                console.log(name,email,pass);

                setName('');
                setEmail('');
                setPass('');
            }
        }

        return<>
            {/* This is the Front End Validation form Section... */}

            <h1 style={{textAlign:"center"}}>Form-Validation</h1>
            {/* Main Section... */}

            <div style={{display:"flex"}} className="main">

            {/* Dividing the sections into two parts... */}

            <div className="col-6">
                <div className="form">
                    {/* Starting of Form Section... */}
                    <form onSubmit={handleForm}>
                       <label>Name : </label>
                        <br/>
                        <input type="text" value={name} placeholder="Enter Your Name" onChange={(e)=>setName(e.target.value)}/>

                        {/* Error Message Process.. */}

                        {errMsg.name && <span style={{color:"red"}}>{errMsg.name}</span>}
                        <br/>
                        <br/>
                        <label>Email : </label>
                        <br/>
                        <input type="email" value={email} placeholder="Enter Your Email Address" onChange={(e)=>setEmail(e.target.value)}/>

                        {/* Error Message Process.. */}

                        {errMsg.email && <span style={{color:"red"}}>{errMsg.email}</span>}
                        <br/>
                        <br/>
                        <label>Password : </label>
                        <br/>
                        <input type="password" value={pass} placeholder="Enter Your Password" onChange={(e)=>setPass(e.target.value)}/>
                        
                        {/* Error Message Process.. */}

                        {errMsg.pass && <span style={{color:"red"}}>{errMsg.pass}</span>}
                        <br/>
                        <br/>
                        <button>Submit</button>
                    </form>
                </div>
            </div>
            <div className="col-6">

                {/* Displaying the Information On the screen... */}

                <div className="info">
                    <h2>{"Name = "+name}</h2>
                    <h2>{"Email = "+email}</h2>
                    <h2>{"Password = "+pass}</h2>
                </div>
            </div>
            </div>
            
        </>
    }