
import './App.css'
import Validation from './Pages/Validation'

function App() {

  return (
    <>
      <Validation/>
    </>
  )
}

export default App
